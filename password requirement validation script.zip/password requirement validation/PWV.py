# Requirement: Password for login
MIN_PW = 8

import hashlib

def ValidateStrongPassword(password):
    # Set all function False
    upp = False
    low = False
    num = False
    spc = False
    cnt = False

    # Three repetation character not found
    noRpt = True

    # Character writing acceptable range
    rng = True

    # Validate allow condition
    pwlen = len(password)

    if pwlen >= MIN_PW:
        cnt = True

    for eachChar in password:
        if eachChar in "ABCDEFGHIJKLMNOPQRSTUVWXYZ":
            upp = True
        elif eachChar in "abcdefghijklmnopqrstuvwxyz":
            low = True
        elif eachChar in "0123456789":
            num = True
        elif eachChar in "(!@#$%^&()_+-={}[];',.`~)":
            spc = True
        else:
            continue

    """ Check for triple repeats """
    pos = 0
    for eachChar in password:
        if pos < pwlen - 2:
            if eachChar == password[pos + 1] and eachChar == password[pos + 2]:
                noRpt = False
            else:
                pos += 1

    for eachChar in password:
        val = ord(eachChar)
        if val < 0x20 or val > 0x7f:
            rng = False

    if upp and low and num and spc and rng and noRpt:
        return True
    else:
        return False

"""
Change password to SHA256
"""

def gen_pass_hash(password):
    try:
        string_to_hash = password
        hash_obj = hashlib.sha256(str(string_to_hash).encode('utf-8'))
        return True, hash_obj.hexdigest()
    except:
        return False, "Hashing Failure"


# Main program starts Here

if __name__ == '__main__':
    # The gen_pass_hash function is susceptible
    # to a rainbow table attack. Therefore, you need to come up with a
    # modification that will make the generated
    # hash value more resilient to such an attack.

    thePass = input("Write your password: ")

    if ValidateStrongPassword(thePass):
        print(thePass, "Meets the Criteria")
        result, resultingHash = gen_pass_hash(thePass)

        if result:
            print("HASH: ", resultingHash)
        else:
            print(resultingHash)
    else:
        print(thePass, "Does not Meet the Criteria")
